/*
 * BleNusBridge
 *
 * Simpler variant of BleNordicUartBridge: a transparent two-way bridge between
 * USB-CDC Serial and the Nordic UART Service (NUS). Receives bytes from the BLE
 * central via NUS RX and prints them to Serial; reads bytes from Serial and sends
 * them to the central via NUS TX notifications.
 *
 * Unlike BleNordicUartBridge, this version:
 *   - Keeps a smaller feature surface and less runtime debug state.
 *   - Can optionally log connect/disconnect and periodic stats to Serial.
 *   - Arms the background GRTC service on connect when requested.
 *   - Keeps a short name in the primary ADV packet so stricter phone scanners
 *     can see the device without needing scan-response data.
 *
 * Use with any NUS-capable BLE app (nRF Toolbox, Serial Bluetooth Terminal, etc.).
 *
 * Steps:
 *   1. Flash and open a serial terminal at 115200 baud.
 *   2. Connect from a BLE app — device advertises as "X54-NUS".
 *   3. Enable notifications in the app and start typing on either side.
 *
 * Gotcha: any Serial logging while bridged data is flowing steals bandwidth from
 * the same USB CDC port. Keep kEnableBridgeLogs off in production.
 */

#include <Arduino.h>

#include "ble_nus.h"

using namespace xiao_nrf54l15;

namespace {

BleRadio g_ble;
BleNordicUart g_nus(g_ble);
PowerManager g_power;

constexpr uint16_t kUsbToBleBufferSize = 2048U;    // Staging buffer for USB→BLE direction.
constexpr uint8_t kUsbToBleChunkBytes = BleNordicUart::kMaxPayloadLength;
constexpr uint16_t kEventNoopStageBytes = 256U;    // Bytes staged between connection events.
constexpr uint16_t kEventStageBytes = 512U;        // Bytes staged on a real connection event.
constexpr uint16_t kEventPumpBytes = 512U;         // Bytes pumped per loop pass.
constexpr uint16_t kBleWriteChunkBytes =
    BleNordicUart::kMaxPayloadLength;              // One full notify-sized staging chunk.
constexpr bool kEnableBridgeLogs = false;
// Keep the background BLE service enabled on the live bridge. The simpler NUS
// sketch still benefits from it when USB CDC bursts would otherwise delay ATT
// progress or outgoing notifications.
constexpr bool kEnableBleBgService = true;
// Use a long poll budget here so the first Sony/Qualcomm connection events are
// not missed while the sketch transitions out of the advertising loop.
constexpr uint32_t kConnectionPollTimeoutUs = 450000UL;
constexpr uint32_t kBridgeWarmupMs = 500UL;
constexpr bool kRequestLinkSecurity = false;
constexpr uint32_t kStatusPeriodMs = 2000UL;       // How often to print streaming stats.
constexpr uint8_t kNoBytes = 0U;

bool g_wasConnected = false;
bool g_bannerSent = false;
bool g_securityRequested = false;
uint32_t g_lastStatusMs = 0U;
uint32_t g_connectedAtMs = 0U;
uint32_t g_usbDroppedBytes = 0U;
uint32_t g_bleDroppedBytes = 0U;
uint32_t g_connSessionRxDropped = 0U;
uint32_t g_connSessionTxDropped = 0U;
uint16_t g_usbToBleHead = 0U;
uint16_t g_usbToBleTail = 0U;
uint16_t g_usbToBleCount = 0U;
uint16_t g_bleToUsbHead = 0U;
uint16_t g_bleToUsbTail = 0U;
uint16_t g_bleToUsbCount = 0U;
uint8_t g_usbToBleBuffer[kUsbToBleBufferSize] = {0};
uint8_t g_bleToUsbBuffer[kUsbToBleBufferSize] = {0};

volatile uint32_t g_nusDiagMagic = 0x4E555344UL;  // "NUSD"
volatile uint32_t g_nusDiagConnectIndCount = 0U;
volatile uint8_t g_nusDiagAdvPeer[6] = {0};
volatile uint8_t g_nusDiagAdvPeerRandom = 0U;
volatile uint8_t g_nusDiagAdvChSel2 = 0U;
volatile int8_t g_nusDiagAdvRssi = 0;
volatile uint8_t g_nusDiagInfoValid = 0U;
volatile uint8_t g_nusDiagInfoPeer[6] = {0};
volatile uint8_t g_nusDiagInfoPeerRandom = 0U;
volatile uint32_t g_nusDiagAccessAddress = 0U;
volatile uint32_t g_nusDiagCrcInit = 0U;
volatile uint16_t g_nusDiagIntervalUnits = 0U;
volatile uint16_t g_nusDiagLatency = 0U;
volatile uint16_t g_nusDiagTimeoutUnits = 0U;
volatile uint8_t g_nusDiagChannelMap[5] = {0};
volatile uint8_t g_nusDiagChannelCount = 0U;
volatile uint8_t g_nusDiagHop = 0U;
volatile uint8_t g_nusDiagSca = 0U;
volatile uint32_t g_nusDiagInfoCaptureCount = 0U;

}  // namespace

// 0 dBm: standard output power, ~10 m indoor range. Range: -40 to +8 dBm.
constexpr int8_t kTxPowerDbm = 0;
// Optional fixed test address. Leave it off by default because the board's
// factory-derived BLE address is more discoverable on some phones.
constexpr uint8_t kAddress[6] = {0x3A, 0x00, 0x15, 0x54, 0xDE, 0xC0};
static constexpr bool kUseFixedAddress = false;
constexpr char kDeviceName[] = "X54-NUS";
// Keep the startup banner within one notification so the bridge begins from a
// clean TX queue and the host regression script can verify a stable first read.
static constexpr char kReadyBanner[] = "X54 NUS ready\r\n";
static const char* disconnectReasonLabel(uint8_t reason) {
  switch (reason) {
    case 0x08:
      return "timeout";
    case 0x13:
      return "remote user";
    case 0x16:
      return "local host";
    case 0x3D:
      return "mic failure";
    default:
      return "other";
  }
}

static void printAddress(const uint8_t* addr) {
  if (addr == nullptr) {
    return;
  }
  for (int i = 5; i >= 0; --i) {
    if (addr[i] < 16U) {
      Serial.print('0');
    }
    Serial.print(addr[i], HEX);
    if (i > 0) {
      Serial.print(':');
    }
  }
}

static void captureAdvConnectDiag(const BleAdvInteraction& adv) {
  ++g_nusDiagConnectIndCount;
  for (uint8_t i = 0U; i < 6U; ++i) {
    g_nusDiagAdvPeer[i] = adv.peerAddress[i];
  }
  g_nusDiagAdvPeerRandom = adv.peerAddressRandom ? 1U : 0U;
  g_nusDiagAdvChSel2 = adv.connectIndChSel2 ? 1U : 0U;
  g_nusDiagAdvRssi = adv.rssiDbm;
}

static void captureConnectionInfoDiag() {
  BleConnectionInfo info{};
  if (!g_ble.getConnectionInfo(&info)) {
    g_nusDiagInfoValid = 0U;
    return;
  }

  for (uint8_t i = 0U; i < 6U; ++i) {
    g_nusDiagInfoPeer[i] = info.peerAddress[i];
  }
  g_nusDiagInfoPeerRandom = info.peerAddressRandom ? 1U : 0U;
  g_nusDiagAccessAddress = info.accessAddress;
  g_nusDiagCrcInit = info.crcInit;
  g_nusDiagIntervalUnits = info.intervalUnits;
  g_nusDiagLatency = info.latency;
  g_nusDiagTimeoutUnits = info.supervisionTimeoutUnits;
  for (uint8_t i = 0U; i < 5U; ++i) {
    g_nusDiagChannelMap[i] = info.channelMap[i];
  }
  g_nusDiagChannelCount = info.channelCount;
  g_nusDiagHop = info.hopIncrement;
  g_nusDiagSca = info.sleepClockAccuracy;
  g_nusDiagInfoValid = 1U;
  ++g_nusDiagInfoCaptureCount;
}

static uint16_t advanceIndex(uint16_t index, uint16_t capacity) {
  ++index;
  if (index >= capacity) {
    index = 0U;
  }
  return index;
}

static void resetBridgeBuffers() {
  g_usbToBleHead = 0U;
  g_usbToBleTail = 0U;
  g_usbToBleCount = 0U;
  g_bleToUsbHead = 0U;
  g_bleToUsbTail = 0U;
  g_bleToUsbCount = 0U;
}

static void stageUsbToBle(int maxBytes) {
  int budget = maxBytes;
  while (budget > 0 && Serial.available() > 0) {
    const int ch = Serial.read();
    if (ch < 0) {
      break;
    }

    if (g_usbToBleCount >= kUsbToBleBufferSize) {
      ++g_usbDroppedBytes;
    } else {
      g_usbToBleBuffer[g_usbToBleHead] = static_cast<uint8_t>(ch);
      g_usbToBleHead = advanceIndex(g_usbToBleHead, kUsbToBleBufferSize);
      ++g_usbToBleCount;
    }
    --budget;
  }
}

static void pumpUsbToBle(int maxBytes) {
  if (!g_nus.isNotifyEnabled() || g_usbToBleCount == 0U) {
    return;
  }

  int budget = g_nus.availableForWrite();
  if (budget > maxBytes) {
    budget = maxBytes;
  }
  if (g_usbToBleCount < static_cast<uint16_t>(budget)) {
    budget = static_cast<int>(g_usbToBleCount);
  }
  if (budget <= 0) {
    return;
  }

  uint8_t chunk[kBleWriteChunkBytes] = {kNoBytes};
  while (budget > 0 && g_usbToBleCount > 0U) {
    int chunkBudget = budget;
    if (chunkBudget > static_cast<int>(sizeof(chunk))) {
      chunkBudget = static_cast<int>(sizeof(chunk));
    }
    if (g_usbToBleCount < static_cast<uint16_t>(chunkBudget)) {
      chunkBudget = static_cast<int>(g_usbToBleCount);
    }
    if (chunkBudget <= 0) {
      break;
    }

    uint16_t index = g_usbToBleTail;
    for (int i = 0; i < chunkBudget; ++i) {
      chunk[i] = g_usbToBleBuffer[index];
      index = advanceIndex(index, kUsbToBleBufferSize);
    }

    const size_t written = g_nus.write(chunk, static_cast<size_t>(chunkBudget));
    if (written == 0U) {
      break;
    }
    for (size_t i = 0; i < written; ++i) {
      g_usbToBleTail = advanceIndex(g_usbToBleTail, kUsbToBleBufferSize);
      --g_usbToBleCount;
    }
    budget -= static_cast<int>(written);
    if (written < static_cast<size_t>(chunkBudget)) {
      break;
    }
  }
}

static void stageBleToUsb(int maxBytes) {
  int budget = maxBytes;
  while (budget > 0 && g_nus.available() > 0) {
    const int ch = g_nus.read();
    if (ch < 0) {
      break;
    }
    if (g_bleToUsbCount >= kUsbToBleBufferSize) {
      ++g_bleDroppedBytes;
    } else {
      g_bleToUsbBuffer[g_bleToUsbHead] = static_cast<uint8_t>(ch);
      g_bleToUsbHead = advanceIndex(g_bleToUsbHead, kUsbToBleBufferSize);
      ++g_bleToUsbCount;
    }
    --budget;
  }
}

static void pumpBleToUsb(int maxBytes) {
  int budget = maxBytes;
  while (budget > 0 && g_bleToUsbCount > 0U) {
    const size_t written = Serial.write(g_bleToUsbBuffer[g_bleToUsbTail]);
    if (written != 1U) {
      break;
    }
    g_bleToUsbTail = advanceIndex(g_bleToUsbTail, kUsbToBleBufferSize);
    --g_bleToUsbCount;
    --budget;
  }
}

static void printDropCounters() {
  if (!kEnableBridgeLogs) {
    return;
  }
  const uint32_t txDropped = g_nus.txDroppedBytes();
  const uint32_t rxDropped = g_nus.rxDroppedBytes();
  if (txDropped <= g_connSessionTxDropped && rxDropped <= g_connSessionRxDropped) {
    return;
  }

  Serial.print("bridge_drops tx=");
  Serial.print(txDropped - g_connSessionTxDropped);
  Serial.print(" rx=");
  Serial.print(rxDropped - g_connSessionRxDropped);
  Serial.print(" usb=");
  Serial.print(g_usbDroppedBytes);
  Serial.print(" ble=");
  Serial.print(g_bleDroppedBytes);
  Serial.print(" queued=");
  Serial.print(g_usbToBleCount);
  Serial.print("/");
  Serial.print(g_bleToUsbCount);
  Serial.print("\r\n");
}

static void printStreamingStats() {
  if (!kEnableBridgeLogs) {
    return;
  }
  const uint32_t nowMs = millis();
  if ((nowMs - g_lastStatusMs) < kStatusPeriodMs) {
    return;
  }
  g_lastStatusMs = nowMs;
  Serial.print("stats pending_tx=");
  Serial.print(g_nus.availableForWrite());
  Serial.print(" usb_q=");
  Serial.print(g_usbToBleCount);
  Serial.print(" ble_q=");
  Serial.print(g_bleToUsbCount);
  Serial.print(" usb_avail=");
  Serial.print(Serial.available());
  Serial.print(" rxq=");
  Serial.print(g_nus.available());
  Serial.print(" mtu=");
  Serial.print(g_nus.maxPayloadLength());
  Serial.print(" notify=");
  Serial.print(g_nus.isNotifyEnabled() ? "on" : "off");
  Serial.print("\r\n");
}

static bool bridgeWarmupElapsed(uint32_t nowMs) {
  return (nowMs - g_connectedAtMs) >= kBridgeWarmupMs;
}

static void maybeRequestLinkSecurity(uint32_t nowMs) {
  if (!kRequestLinkSecurity || g_securityRequested || !g_ble.isConnected()) {
    return;
  }
  if (!bridgeWarmupElapsed(nowMs)) {
    return;
  }
  g_securityRequested = true;
  g_ble.sendSmpSecurityRequest();
}

void setup() {
  Serial.begin(115200);
  delay(350);
  Serial.print("\r\nBleNusBridge start\r\n");

  Gpio::configure(kPinUserLed, GpioDirection::kOutput, GpioPull::kDisabled);
  Gpio::write(kPinUserLed, true);

  // kCeramic: route RF through the on-board ceramic chip antenna (default).
  // Use kExternal if a u.FL external antenna is connected.
  bool ok = BoardControl::setAntennaPath(BoardAntennaPath::kCeramic);
  if (ok) {
    ok = g_ble.begin(kTxPowerDbm);
  }
  if (ok) {
    g_power.setLatencyMode(PowerLatencyMode::kConstantLatency);
  }
  if (ok) {
    ok = (!kUseFixedAddress ||
          g_ble.setDeviceAddress(kAddress, BleAddressType::kRandomStatic)) &&
         g_ble.setAdvertisingPduType(BleAdvPduType::kAdvInd) &&
         g_ble.setAdvertisingChannelSelectionAlgorithm2(true) &&
         g_ble.setGattDeviceName(kDeviceName) &&
         g_ble.setGattBatteryLevel(100U) &&
         g_ble.clearCustomGatt() &&
         g_nus.begin();
  }

  Serial.print("BLE NUS init: ");
  Serial.print(ok ? "OK" : "FAIL");
  Serial.print("\r\n");
  if (ok) {
    Serial.print("Advertised as X54-NUS. Open a Nordic UART client and bridge bytes.\r\n");
    uint8_t addr[6];
    BleAddressType type = BleAddressType::kPublic;
    if (g_ble.getDeviceAddress(addr, &type)) {
      Serial.print("addr=");
      printAddress(addr);
      Serial.print(" type=");
      Serial.print((type == BleAddressType::kRandomStatic) ? "random" : "public");
      Serial.print("\r\n");
    }
  }
}

void loop() {
  if (!g_ble.isConnected()) {
    BleAdvInteraction adv{};
    g_ble.advertiseInteractEvent(&adv, 350U, 350000UL, 700000UL);
    if (adv.receivedConnectInd) {
      captureAdvConnectDiag(adv);
    }
    g_nus.service();

    if (g_wasConnected) {
      g_wasConnected = false;
      g_bannerSent = false;
      g_securityRequested = false;
      g_usbDroppedBytes = 0U;
      g_bleDroppedBytes = 0U;
      resetBridgeBuffers();
      printDropCounters();
      printStreamingStats();
      Gpio::write(kPinUserLed, true);
      if (kEnableBridgeLogs) {
        Serial.print("\r\nBLE client disconnected\r\n");
      }
    }

    // Only pace the advertising loop when still disconnected after
    // advertiseInteractEvent(). If a CONNECT_IND was just accepted, skip the
    // delay so the first pollConnectionEvent() reaches the anchor on time.
    if (!g_ble.isConnected()) {
      delay(100);
    }
    return;
  }

  if (!g_wasConnected) {
    g_wasConnected = true;
    g_bannerSent = false;
    g_securityRequested = false;
    g_connectedAtMs = millis();
    g_usbDroppedBytes = 0U;
    g_bleDroppedBytes = 0U;
    g_connSessionRxDropped = g_nus.rxDroppedBytes();
    g_connSessionTxDropped = g_nus.txDroppedBytes();
    resetBridgeBuffers();
    // Arm the background GRTC service so ATT/SMP responses are handled even if
    // the main loop is briefly delayed by Serial.print() calls.
    if (kEnableBleBgService) {
      g_ble.setBackgroundConnectionServiceEnabled(true);
    }
    Gpio::write(kPinUserLed, false);
    if (kEnableBridgeLogs) {
      Serial.print("\r\nBLE client connected\r\n");
    }
  }

  // Keep BLE connection-event polling tight; missing anchors leads to 0x08 timeouts.
  BleConnectionEvent evt{};
  const bool eventStarted =
      g_ble.pollConnectionEvent(&evt, kConnectionPollTimeoutUs) && evt.eventStarted;

  // The HAL deferred event queue is not flushed on disconnect. The first
  // pollConnectionEvent() of a new connection may return the previous
  // connection's terminateInd=true. Passing that stale event to
  // g_nus.service() resets the NUS CCCD state, forcing Android to re-discover
  // and re-write it — causing the "serial not connected" symptom.
  if (evt.terminateInd && g_ble.isConnected()) {
    evt.terminateInd = false;
  }

  if (!eventStarted) {
    g_nus.service();
    const uint32_t nowMs = millis();
    maybeRequestLinkSecurity(nowMs);
    if (!bridgeWarmupElapsed(nowMs)) {
      return;
    }
    stageUsbToBle(static_cast<int>(kEventNoopStageBytes));
    stageBleToUsb(static_cast<int>(kEventNoopStageBytes));
    pumpUsbToBle(static_cast<int>(kEventPumpBytes));
    pumpBleToUsb(static_cast<int>(kEventPumpBytes));
    return;
  }

  g_nus.service(&evt);
  const uint32_t nowMs = millis();
  maybeRequestLinkSecurity(nowMs);
  if (evt.terminateInd) {
    if (kEnableBridgeLogs) {
      Serial.print("BLE link terminated");
      if (evt.disconnectReasonValid) {
        Serial.print(" reason=0x");
        if (evt.disconnectReason < 0x10U) {
          Serial.print('0');
        }
        Serial.print(evt.disconnectReason, HEX);
        Serial.print(" (");
        Serial.print(disconnectReasonLabel(evt.disconnectReason));
        Serial.print(", ");
        Serial.print(evt.disconnectReasonRemote ? "peer" : "local");
        Serial.print(")");
      }
      Serial.print("\r\n");
    }
    printDropCounters();
  }

  if (!bridgeWarmupElapsed(nowMs)) {
    return;
  }

  // Only pump UART after a real connection event.
  stageUsbToBle(static_cast<int>(kEventStageBytes));
  stageBleToUsb(static_cast<int>(kEventStageBytes));
  pumpUsbToBle(static_cast<int>(kEventPumpBytes));
  pumpBleToUsb(static_cast<int>(kEventPumpBytes));
  printStreamingStats();

  if (!g_bannerSent && g_nus.isNotifyEnabled()) {
    g_bannerSent = true;
    g_nus.write(reinterpret_cast<const uint8_t*>(kReadyBanner), sizeof(kReadyBanner) - 1U);
  }
}
